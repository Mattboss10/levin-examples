---
name: speed-up-cbmc-kani-proofs
description: Use when a CBMC (C, C++) or Kani (Rust) proof check is slow. Swaps the default SAT solver for kissat and cadical racing on your own computer, often minutes down to seconds, with an optional mode where every "no bug" answer is backed by a proof that drat-trim verifies. Runs locally; nothing is sent anywhere.
---

# Speed up slow CBMC and Kani proofs

CBMC solves its formulas with MiniSAT by default. Modern solvers are often far faster on the
same formula: on one benchmark check (a hash finalizer, 2,641 variables) CBMC's default
solver ran past 10 minutes, while kissat answered in about 4 seconds. This skill plugs faster
solvers into the checker you already run. Everything runs on this computer.

## Before you start

Needs `kissat` or `cadical` on the PATH (both open source); certified mode also needs
`cadical` and `drat-trim`. Check with `command -v kissat cadical drat-trim`. If one is
missing, tell the user and suggest their package manager (for example
`brew install kissat cadical`, or `apt install cadical`), or building from the official
sources: github.com/arminbiere/kissat, github.com/arminbiere/cadical,
github.com/marijnheule/drat-trim. Ask before installing anything.

## Steps

1. Copy `scripts/fast-sat` from this skill into the folder you run the check from and make it
   executable (`chmod +x fast-sat`). Read it first if you like: about 40 lines of shell. It
   races kissat and cadical on the formula the checker hands it and prints the first answer.
2. Re-run the check with it, in the background if it may take minutes:
   - CBMC: `cbmc <args> --external-sat-solver ./fast-sat`
   - Kani: `cargo kani --harness <name> --solver kissat` (built in), or
     `--solver bin=<full path>/fast-sat` to race both solvers.

   The checker prints its own result as usual: `VERIFICATION SUCCESSFUL`, or a failure with
   a counterexample trace.
3. For an answer you can audit, use certified mode: `FAST_SAT_CERTIFY=1 cbmc <args>
   --external-sat-solver ./fast-sat`. cadical writes a proof that no counterexample exists,
   and the answer is accepted only if drat-trim verifies that proof; otherwise the checker
   reports an error rather than a success. It is slower (the 4-second example above takes
   about 36 seconds), so use it for the result you will rely on.
4. Still too slow? Shrink the problem, then grow it: lower `--unwind` or the `-D` sizes until
   it finishes, check one property at a time (`--property <name>`), and add
   `--slice-formula`. Keep `--unwinding-assertions` so a too-small bound is reported, not
   hidden.
5. Report the exact command and its bounds (harness, `--unwind`, `-D` values): the answer
   holds for those bounds only. Say whether certified mode was used.
